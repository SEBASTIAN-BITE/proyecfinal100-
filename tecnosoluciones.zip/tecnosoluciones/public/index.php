<?php
// Este es el punto de entrada de la aplicación MVC
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/conexion.php';
require_once '../controllers/UsuarioController.php';
require_once '../controllers/ClienteController.php';
require_once '../controllers/ProyectoController.php';

$controllerName = $_GET['controller'] ?? 'Usuario';
$action = $_GET['action'] ?? 'login';

// Determinar qué controlador usar
switch ($controllerName) {
    case 'Cliente':
        $controller = new ClienteController();
        break;
    case 'Proyecto':
        $controller = new ProyectoController();
        break;
    case 'Usuario':
    default:
        $controller = new UsuarioController();
        break;
}

// Llamar a la acción correspondiente
if (method_exists($controller, $action)) {
    $controller->{$action}();
} else {
    // Si no existe la acción, mostrar login por defecto
    $controller->login();
}
?>