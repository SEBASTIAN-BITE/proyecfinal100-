<?php
// Destroy session and redirect to login
session_start();
session_unset();
session_destroy();
header("Location: index.php?controller=Usuario&action=login");
exit;
?>
