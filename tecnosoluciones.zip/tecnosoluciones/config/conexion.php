<?php
class Conexion {
    private static $instancia = null;
    private $conexion;

    // Constructor privado para prevenir múltiples instancias
    private function __construct() {
        try {
            $this->conexion = new PDO(
                "mysql:host=localhost;
                dbname=tecnosoluciones;
                charset=utf8",
                "root", "" // usuario y contraseña de MySQL por defecto
            );
            // Establecer el modo de error de PDO a excepción
            $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    // Método estático para obtener la instancia de conexión
    public static function conectar() {
        if (self::$instancia === null) {
            self::$instancia = new Conexion();
        }
        return self::$instancia->conexion;
    }
}
?>
