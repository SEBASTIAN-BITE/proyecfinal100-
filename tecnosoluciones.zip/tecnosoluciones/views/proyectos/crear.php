<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Crear Proyecto - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/proyectoscrear.css">
</head>
<body>
    <div class="container">
        <h1>Crear Proyecto</h1>
        <form method="post" action="index.php?controller=Proyecto&action=crear">
            <label>Nombre:</label>
            <input type="text" name="nombre" required>

            <label>Descripción:</label>
            <textarea name="descripcion" rows="4"></textarea>

            <label>Cliente:</label>
            <select name="cliente_id" required>
                <option value="">-- Seleccione un cliente --</option>
                <?php
                require_once '../models/Cliente.php';
                $clienteModel = new Cliente();
                $listaClientes = $clienteModel->getAll();
                foreach ($listaClientes as $c): ?>
                    <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['nombre']); ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Guardar</button>
            <a class="cancel-btn" href="index.php?controller=Proyecto&action=listar">Cancelar</a>
        </form>
    </div>
</body>
</html>
