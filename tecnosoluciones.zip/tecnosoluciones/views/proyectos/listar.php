<!-- views/proyectos/listar.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Proyectos - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/proyectoslistar.css">
</head>
<body>
    <div class="container">
        <h1>Lista de Proyectos</h1>
        <a class="new-btn" href="index.php?controller=Proyecto&action=crear">+ Nuevo Proyecto</a>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Cliente</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($proyectos as $p): ?>
                <tr>
                    <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($p['descripcion']); ?></td>
                    <td><?php echo htmlspecialchars($p['cliente_nombre']); ?></td>
                    <td>
                        <a class="edit" href="index.php?controller=Proyecto&action=editar&id=<?php echo $p['id']; ?>">Editar</a>
                        <a class="delete" href="index.php?controller=Proyecto&action=eliminar&id=<?php echo $p['id']; ?>">Eliminar</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a class="dashboard-link" href="index.php?controller=Usuario&action=dashboard">← Volver al Dashboard</a>
    </div>
</body>
</html>
