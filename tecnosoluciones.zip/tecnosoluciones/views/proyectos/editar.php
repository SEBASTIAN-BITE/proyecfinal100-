<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Proyecto - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/proyectoseditar.css">
    <script src="" defer></script>
</head>
<body>
    <div class="container">
        <h1>Editar Proyecto</h1>
        <form method="post" action="index.php?controller=Proyecto&action=editar&id=<?php echo $proyecto['id']; ?>">
            <label>Nombre:</label>
            <input type="text" name="nombre" value="<?php echo htmlspecialchars($proyecto['nombre']); ?>" required>

            <label>Descripción:</label>
            <textarea name="descripcion"><?php echo htmlspecialchars($proyecto['descripcion']); ?></textarea>

            <label>Cliente:</label>
            <select name="cliente_id" required>
                <option value="">-- Seleccione un cliente --</option>
                <?php
                require_once '../models/Cliente.php';
                $clienteModel = new Cliente();
                $listaClientes = $clienteModel->getAll();
                foreach ($listaClientes as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php if ($c['id'] == $proyecto['cliente_id']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($c['nombre']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Actualizar</button>
            <a class="cancel-btn" href="index.php?controller=Proyecto&action=listar">Cancelar</a>
        </form>
    </div>
</body>
</html>
