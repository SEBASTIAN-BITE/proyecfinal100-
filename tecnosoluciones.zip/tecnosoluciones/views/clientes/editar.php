<!-- views/clientes/editar.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Cliente - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/clienteseditar.css">
</head>
<body>
    <div class="container">
        <h1>Editar Cliente</h1>
        <form method="post" action="index.php?controller=Cliente&action=editar&id=<?php echo $cliente['id']; ?>">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($cliente['nombre']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($cliente['email']); ?>">

            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($cliente['telefono']); ?>">

            <button type="submit">Actualizar</button>
        </form>
        <a class="cancel-link" href="index.php?controller=Cliente&action=listar">Cancelar</a>
    </div>

    <div class="loader" id="loader">Actualizando cliente...</div>
</body>
</html>
