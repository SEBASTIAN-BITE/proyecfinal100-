<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Crear Cliente - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/clientescrear.css">
</head>
<body>
    <div class="container">
        <h1>Crear Cliente</h1>
        <form method="post" action="index.php?controller=Cliente&action=crear">
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email">

            <label for="telefono">Teléfono:</label>
            <input type="text" name="telefono" id="telefono">

            <button type="submit">Guardar</button>
        </form>
        <a href="index.php?controller=Cliente&action=listar">Cancelar</a>
    </div>
</body>
</html>
