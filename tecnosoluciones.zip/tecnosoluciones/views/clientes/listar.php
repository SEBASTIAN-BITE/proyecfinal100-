<!-- views/clientes/listar.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Clientes - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/clienteslistar.css">
    <script src="" defer></script>
</head>
<body>
    <div class="loader">Cargando...</div>
    <h1>Lista de Clientes</h1>
    <a href="index.php?controller=Cliente&action=crear">Nuevo Cliente</a><br><br>
    <table>
        <tr>
            <th>Nombre</th><th>Email</th><th>Teléfono</th><th>Acciones</th>
        </tr>
        <?php foreach ($clientes as $c): ?>
        <tr>
            <td><?php echo htmlspecialchars($c['nombre']); ?></td>
            <td><?php echo htmlspecialchars($c['email']); ?></td>
            <td><?php echo htmlspecialchars($c['telefono']); ?></td>
            <td>
                <a href="index.php?controller=Cliente&action=editar&id=<?php echo $c['id']; ?>">Editar</a>
                <a href="index.php?controller=Cliente&action=eliminar&id=<?php echo $c['id']; ?>">Eliminar</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <p><a href="index.php?controller=Usuario&action=dashboard">Volver al Dashboard</a></p>
</body>
</html>
