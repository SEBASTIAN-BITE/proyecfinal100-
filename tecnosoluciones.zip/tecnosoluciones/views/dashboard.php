<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <script src="" defer></script>
</head>
<body>
    <div class="container">
        <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']['username']); ?></h1>

        <nav>
            <ul>
                <li><a href="index.php?controller=Cliente&action=listar">Tus Clientes</a></li>
                <li><a href="index.php?controller=Proyecto&action=listar">Tus Proyectos</a></li>
                <li><a href="../pdf/generar_pdf.php?tipo=clientes">Generar PDF de Clientes</a></li>
                <li><a href="../pdf/generar_pdf.php?tipo=proyectos">Generar PDF de Proyectos</a></li>
                <li><a href="logout.php">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>
