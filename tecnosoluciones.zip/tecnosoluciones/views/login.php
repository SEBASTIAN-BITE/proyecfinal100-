<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login - TecnoSoluciones</title>
    <link rel="stylesheet" href="../assets/css/principales.css">
    <script src="../assets/js/principales.js" defer></script>
</head>
<body>
    <!-- Barra de carga -->
    <div id="loader">
        <div class="glow-bar"></div>
        <p>Iniciando sesión...</p>
    </div>

    <!-- Contenedor principal -->
    <div class="container" id="loginContainer">
        <h2>Iniciar Sesión</h2>

        <?php if (isset($error)): ?>
            <p class="error-msg"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post" action="index.php?controller=Usuario&action=login" id="loginForm">
            <label for="username">Usuario:</label>
            <input type="text" id="username" name="username" required><br><br>

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required><br><br>

            <button type="submit">Entrar</button>
        </form>

        <div class="register-link">
            ¿No tienes cuenta? 
            <a href="index.php?controller=Usuario&action=registro">Regístrate</a>
        </div>
    </div>
</body>
</html>