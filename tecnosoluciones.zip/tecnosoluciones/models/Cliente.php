<?php
require_once '../config/conexion.php';

class Cliente {
    private $pdo;

    public function __construct() {
        $this->pdo = Conexion::conectar();
    }

    // Listar todos los clientes
    public function getAll() {
        $sql = "SELECT * FROM clientes";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener cliente por ID
    public function getById($id) {
        $sql = "SELECT * FROM clientes WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Crear un nuevo cliente
    public function crear($nombre, $email, $telefono) {
        $sql = "INSERT INTO clientes (nombre, email, telefono) VALUES (:nombre, :email, :telefono)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':nombre' => $nombre, ':email' => $email, ':telefono' => $telefono]);
    }

    // Actualizar cliente existente
    public function actualizar($id, $nombre, $email, $telefono) {
        $sql = "UPDATE clientes SET nombre = :nombre, email = :email, telefono = :telefono WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':nombre' => $nombre, ':email' => $email, ':telefono' => $telefono, ':id' => $id]);
    }

    // Eliminar cliente
    public function eliminar($id) {
        $sql = "DELETE FROM clientes WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
?>
