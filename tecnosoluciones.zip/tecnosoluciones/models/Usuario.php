<?php
require_once '../config/conexion.php';

class Usuario {
    private $pdo;

    public function __construct() {
        $this->pdo = Conexion::conectar();
    }

    // Verificar login: retorna datos de usuario si coincide username y password
    public function login($username, $password) {
        $sql = "SELECT * FROM usuarios WHERE username = :username AND password = :password";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':username' => $username, ':password' => $password]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Obtener todos los usuarios
    public function getAll() {
        $sql = "SELECT * FROM usuarios";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener un usuario por ID
    public function getById($id) {
        $sql = "SELECT * FROM usuarios WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Crear un nuevo usuario (registro)
    public function crear($username, $password) {
        $sql = "INSERT INTO usuarios (username, password) VALUES (:username, :password)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':username' => $username, ':password' => $password]);
    }

    // Actualizar usuario existente
    public function actualizar($id, $username, $password) {
        $sql = "UPDATE usuarios SET username = :username, password = :password WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':username' => $username, ':password' => $password, ':id' => $id]);
    }

    // Eliminar usuario
    public function eliminar($id) {
        $sql = "DELETE FROM usuarios WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
?>
