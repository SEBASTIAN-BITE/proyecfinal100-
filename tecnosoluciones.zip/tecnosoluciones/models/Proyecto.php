<?php
require_once '../config/conexion.php';

class Proyecto {
    private $pdo;

    public function __construct() {
        $this->pdo = Conexion::conectar();
    }

    // Listar todos los proyectos (opcionalmente con nombre de cliente)
    public function getAll() {
        $sql = "SELECT p.id, p.nombre, p.descripcion, p.cliente_id, c.nombre AS cliente_nombre
                FROM proyectos p
                LEFT JOIN clientes c ON p.cliente_id = c.id";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener proyecto por ID
    public function getById($id) {
        $sql = "SELECT * FROM proyectos WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Crear nuevo proyecto
    public function crear($nombre, $descripcion, $cliente_id) {
        $sql = "INSERT INTO proyectos (nombre, descripcion, cliente_id) VALUES (:nombre, :descripcion, :cliente_id)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            ':nombre' => $nombre,
            ':descripcion' => $descripcion,
            ':cliente_id' => $cliente_id
        ]);
    }

    // Actualizar proyecto existente
    public function actualizar($id, $nombre, $descripcion, $cliente_id) {
        $sql = "UPDATE proyectos SET nombre = :nombre, descripcion = :descripcion, cliente_id = :cliente_id WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([
            ':nombre' => $nombre,
            ':descripcion' => $descripcion,
            ':cliente_id' => $cliente_id,
            ':id' => $id
        ]);
    }

    // Eliminar proyecto
    public function eliminar($id) {
        $sql = "DELETE FROM proyectos WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
?>
