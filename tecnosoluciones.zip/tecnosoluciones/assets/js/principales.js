document.addEventListener('DOMContentLoaded', () => {
    const loader = document.getElementById('loader');
    const form = document.getElementById('loginForm');
    const container = document.getElementById('loginContainer');

    form.addEventListener('submit', (e) => {
        // Mostrar animación antes de enviar
        e.preventDefault(); // Detiene envío inmediato

        loader.style.display = 'flex';
        container.style.display = 'none';

        // Simula "esperar" la animación antes de enviar el formulario real
        setTimeout(() => {
            form.submit();
        }, 2000);
    });
});
