<?php
require_once '../models/Usuario.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

class UsuarioController {
    private $usuarioModel;

    public function __construct() {
        $this->usuarioModel = new Usuario();
    }

    // Mostrar formulario de login o procesar login
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $usuario = $this->usuarioModel->login($username, $password);
            if ($usuario) {
                // Iniciar sesión y redirigir al dashboard
                $_SESSION['usuario'] = $usuario;
                header("Location: index.php?controller=Usuario&action=dashboard");
                exit;
            } else {
                $error = "Credenciales inválidas";
                include '../views/login.php';
            }
        } else {
            // Mostrar formulario de login
            include '../views/login.php';
        }
    }

    // Mostrar formulario de registro o procesar registro
    public function registro() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            // Crear usuario (sin encriptar contraseña, como se indicó)
            if ($this->usuarioModel->crear($username, $password)) {
                header("Location: index.php?controller=Usuario&action=login");
                exit;
            } else {
                $error = "Error al registrar usuario";
                include '../views/registro.php';
            }
        } else {
            include '../views/registro.php';
        }
    }

    // Mostrar dashboard (solo si sesión activa)
    public function dashboard() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        include '../views/dashboard.php';
    }

    // Cerrar sesión
    public function logout() {
        session_unset();
        session_destroy();
        header("Location: index.php?controller=Usuario&action=login");
        exit;
    }
}
?>
