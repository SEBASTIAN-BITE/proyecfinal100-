<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../models/Proyecto.php';
class ProyectoController {
    private $proyectoModel;

    public function __construct() {
        $this->proyectoModel = new Proyecto();
    }

    // Listar proyectos
    public function listar() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        $proyectos = $this->proyectoModel->getAll();
        include '../views/proyectos/listar.php';
    }

    // Crear proyecto
    public function crear() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'] ?? '';
            $descripcion = $_POST['descripcion'] ?? '';
            $cliente_id = $_POST['cliente_id'] ?? null;
            $this->proyectoModel->crear($nombre, $descripcion, $cliente_id);
            header("Location: index.php?controller=Proyecto&action=listar");
            exit;
        } else {
            include '../views/proyectos/crear.php';
        }
    }

    // Editar proyecto
    public function editar() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        $id = $_GET['id'] ?? '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'] ?? '';
            $descripcion = $_POST['descripcion'] ?? '';
            $cliente_id = $_POST['cliente_id'] ?? null;
            $this->proyectoModel->actualizar($id, $nombre, $descripcion, $cliente_id);
            header("Location: index.php?controller=Proyecto&action=listar");
            exit;
        } else {
            $proyecto = $this->proyectoModel->getById($id);
            include '../views/proyectos/editar.php';
        }
    }

    // Eliminar proyecto
    public function eliminar() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        $id = $_GET['id'] ?? '';
        if ($id) {
            $this->proyectoModel->eliminar($id);
        }
        header("Location: index.php?controller=Proyecto&action=listar");
        exit;
    }
}
?>
