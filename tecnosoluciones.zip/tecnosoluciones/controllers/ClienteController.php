<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../models/Cliente.php';

class ClienteController {
    private $clienteModel;

    public function __construct() {
        $this->clienteModel = new Cliente();
    }

    // Listar clientes
    public function listar() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        $clientes = $this->clienteModel->getAll();
        include '../views/clientes/listar.php';
    }

    // Crear cliente
    public function crear() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'] ?? '';
            $email = $_POST['email'] ?? '';
            $telefono = $_POST['telefono'] ?? '';
            $this->clienteModel->crear($nombre, $email, $telefono);
            header("Location: index.php?controller=Cliente&action=listar");
            exit;
        } else {
            include '../views/clientes/crear.php';
        }
    }

    // Editar cliente
    public function editar() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        $id = $_GET['id'] ?? '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'] ?? '';
            $email = $_POST['email'] ?? '';
            $telefono = $_POST['telefono'] ?? '';
            $this->clienteModel->actualizar($id, $nombre, $email, $telefono);
            header("Location: index.php?controller=Cliente&action=listar");
            exit;
        } else {
            $cliente = $this->clienteModel->getById($id);
            include '../views/clientes/editar.php';
        }
    }

    // Eliminar cliente
    public function eliminar() {
        if (!isset($_SESSION['usuario'])) {
            header("Location: index.php?controller=Usuario&action=login");
            exit;
        }
        $id = $_GET['id'] ?? '';
        if ($id) {
            $this->clienteModel->eliminar($id);
        }
        header("Location: index.php?controller=Cliente&action=listar");
        exit;
    }
}
?>
