<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../config/conexion.php';
require_once '../tcpdf/tcpdf.php';

// Proteger la ruta
if (!isset($_SESSION['usuario'])) {
    header("Location: ../public/index.php?controller=Usuario&action=login");
    exit;
}

// Determinar si generamos reporte de clientes o proyectos
$tipo = $_GET['tipo'] ?? 'clientes';
$pdo = Conexion::conectar();

if ($tipo === 'clientes') {
    $stmt = $pdo->query("SELECT * FROM clientes");
    $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $titulo = "Reporte de Clientes";
    // Generar contenido HTML para clientes
    $html = '<h1>' . $titulo . '</h1>';
    $html .= '<table border="1" cellpadding="4">
                <tr><th>ID</th><th>Nombre</th><th>Email</th><th>Teléfono</th></tr>';
    foreach ($registros as $r) {
        $html .= '<tr>
                    <td>' . $r['id'] . '</td>
                    <td>' . htmlspecialchars($r['nombre']) . '</td>
                    <td>' . htmlspecialchars($r['email']) . '</td>
                    <td>' . htmlspecialchars($r['telefono']) . '</td>
                  </tr>';
    }
    $html .= '</table>';
} else {
    // Reporte de proyectos
    $stmt = $pdo->query("SELECT p.id, p.nombre, p.descripcion, c.nombre AS cliente 
                         FROM proyectos p 
                         LEFT JOIN clientes c ON p.cliente_id = c.id");
    $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $titulo = "Reporte de Proyectos";
    $html = '<h1>' . $titulo . '</h1>';
    $html .= '<table border="1" cellpadding="4">
                <tr><th>ID</th><th>Nombre</th><th>Descripción</th><th>Cliente</th></tr>';
    foreach ($registros as $r) {
        $html .= '<tr>
                    <td>' . $r['id'] . '</td>
                    <td>' . htmlspecialchars($r['nombre']) . '</td>
                    <td>' . htmlspecialchars($r['descripcion']) . '</td>
                    <td>' . htmlspecialchars($r['cliente']) . '</td>
                  </tr>';
    }
    $html .= '</table>';
}

// Crear el PDF usando TCPDF
$pdf = new TCPDF();
$pdf->AddPage();
$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output($titulo . '.pdf', 'I');
